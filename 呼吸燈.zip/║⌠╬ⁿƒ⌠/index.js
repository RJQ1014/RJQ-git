/**
 * Created by MrGao on 2016/12/23.
 */
$(function(){

    dark();



    function light(){
        $(".down").stop().animate({"opacity":"1"},2000,"linear",function(){
            console.log("dark")
            dark();
        })
    }

    function dark(){
        $(".down").stop().animate({"opacity":"0"},2000,"linear",function(){
            console.log(" light")
            light();
        })
    }

})